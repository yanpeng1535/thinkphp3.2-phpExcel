<?php

function test1(){
	echo "test1";
}


<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>admin</title>
	<style>
		a,span{
			border: 1px solid #000;
			padding: 5px;
			margin: 5px;
		}
	</style>
</head>
<body style="text-align: center;">
	<h1>phpExcel使用教程</h1>
	<p><a href="<?php echo U('Admin/Index/exp');?>">导出信息</a></p>
	<p><form action="<?php echo U('Admin/Index/imp');?>" method="post" enctype="multipart/form-data">
		<input type="file" name="import">
		<input type="submit" value="提交">
	</form></p>
	<table border="1" cellspacing="0" cellpadding="0" align="center">
		<tr>	
			<th>学号</th>
			<th>姓名</th>
			<th>籍贯</th>
			<th>学院</th>
			<th>爱好</th>
		</tr>
		<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
				<td><?php echo ($vo["stuno"]); ?></td>
				<td><?php echo ($vo["stuname"]); ?></td>
				<td><?php echo ($vo["jg"]); ?></td>
				<td><?php echo ($vo["department"]); ?></td>
				<td><?php echo ($vo["hobby"]); ?></td>
			</tr><?php endforeach; endif; else: echo "" ;endif; ?>
	</table>
	<p><?php echo ($page); ?></p>
</body>
</html>
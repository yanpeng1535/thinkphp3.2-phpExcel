<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {

	/**
	 * 加载视图
	 * @return [type] [description]
	 */
    public function index(){
    	echo "Home";
    }
}
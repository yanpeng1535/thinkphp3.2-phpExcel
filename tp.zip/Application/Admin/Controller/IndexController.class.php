<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends CommonController {

	/**
	 * 加载页面
	 * @return [type] [description]
	 */
    public function index(){
    	$User = M('student'); // 实例化User对象
  		$count = $User->count();// 查询满足要求的总记录数
  		$Page = new \Think\Page($count,6);// 实例化分页类 传入总记录数和每页显示的记录数(25)
  		$show = $Page->show();// 分页显示输出
  		// 进行分页数据查询 注意limit方法的参数要使用Page类的属性
  		$list = $User->order('id')->limit($Page->firstRow.','.$Page->listRows)->select();
  		$this->assign('list',$list);// 赋值数据集
  		$this->assign('page',$show);// 赋值分页输出
  		$this->display(); // 输出模板
    }

    /**
     * 导出
     * @return [type] [description]
     */
    public function exp(){
    	$data = M('student')->select();
    	$xlsName = "学生信息表";
    	$xlsCell = array(
			array('stuno','学号'),
			array('stuname','姓名'),
			array('jg','籍贯'),
			array('department','学院'),
			array('hobby','爱好')
    	);
    	$this->exportExcel($xlsName,$xlsCell,$data);
    }

    /**
     * 导入Excel
     * @return [type] [description]
     */
    public function imp(){

    	$Model = M('student');

     	if(isset($_FILES["import"]) && ($_FILES["import"]["error"] == 0)){
	        $result = $this->importExecl($_FILES["import"]["tmp_name"]);
	        if($result["error"] == 1){          
	          	$execl_data = $result["data"][0]["Content"];
	          	array_splice($execl_data, 1, 0);
                unset($execl_data[0]);
	          	/*将数组的键改为自定义名称*/
                $keys = array('stuno', 'stuname', 'jg', 'department', 'hobby');
              	foreach($execl_data as $k=>$v){
              		/*用数组键和值进行合并*/
      				$re[$k] = array_combine($keys, $v);
              	}
              	foreach ($re as $data) {
              		//加入数据库表
              		$res = $Model->add($data);
              		if ($res) {
              			echo "导入成功！".$res."<br>";
              		}
              	}
              	$this->success("全部导入成功！");
         	}
      	}
	}


}
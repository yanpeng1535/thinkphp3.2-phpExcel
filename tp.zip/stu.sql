/*
Navicat MySQL Data Transfer

Source Server         : Mysql
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : stu

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2020-08-23 18:41:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `is_admin` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('5', 'mange', '123456', '1');
INSERT INTO `admin` VALUES ('4', 'admin', '123456', '1');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stuno` varchar(255) NOT NULL,
  `stuname` varchar(255) DEFAULT NULL,
  `jg` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `hobby` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('2', '19041010002', '秦敏泽', '汕头南澳', '艺术学院', '跳舞，学习，画画，音乐', '123');
INSERT INTO `student` VALUES ('3', '19041010003', '田河', '佛山江门', '医学院', '打篮球，计算机编程', '123');
INSERT INTO `student` VALUES ('4', '19041010004', '张居平', '湛江遂溪', '护理学院', '编程', '123');
INSERT INTO `student` VALUES ('5', '19041010005', '柴雅丽', '茂名电白', '美术学院', '绘画', '123');
INSERT INTO `student` VALUES ('6', '19041010007', '刘年', '肇庆广宁', '文学院', '音乐', '123');
INSERT INTO `student` VALUES ('7', '19041010008', '张希舟', '惠州博罗', '理工学院', '看书', '123');
INSERT INTO `student` VALUES ('8', '19041010009', '杨雁泽', '梅州梅县', '师范学院', '读小说', '123');
INSERT INTO `student` VALUES ('9', '19041010010', '李延潮', '汕尾海丰', '人工智能学院', '兵乓球', '123');
INSERT INTO `student` VALUES ('10', '19041010011', '潘岳', '河源紫金', '软件学院', '足球，篮球，旅游，打游戏', '123');
INSERT INTO `student` VALUES ('11', '19041010012', '曹泽庆', '阳江阳西', '教育技术学院', '跑步', '123');
INSERT INTO `student` VALUES ('12', '19041010013', '吕佰旭', '清远佛冈', '哲学院', '看电影', '123');
INSERT INTO `student` VALUES ('13', '19041010014', '李金泉', '潮州潮安', '马克思主义学院', '写小说，读书，看报纸', '123');
INSERT INTO `student` VALUES ('16', '19041010001', '柯发平', '深圳', '人工智能学院', '学习', '123');
INSERT INTO `student` VALUES ('17', '19041010015', '李晶', '广西桂林', '软件学院', '学习计算机技术', '123');
INSERT INTO `student` VALUES ('18', '19041010015', '王海元', '广西', '软件学院', '打篮球', '123');
INSERT INTO `student` VALUES ('19', '1801020116', '赵崇燕', ' 汕头南澳', ' 软件学院', ' 跳舞，学习，画画，音乐', null);
INSERT INTO `student` VALUES ('20', '1801060117', '赵述和', ' 佛山江门', ' 软件学院', ' 打篮球，计算机编程', null);
INSERT INTO `student` VALUES ('21', '1801080118', '毛英杰', ' 湛江遂溪', ' 软件学院', ' 编程', null);
INSERT INTO `student` VALUES ('22', '1801130119', '张皓宸', ' 茂名电白', ' 软件学院', ' 绘画', null);
INSERT INTO `student` VALUES ('23', '1801150120', '柯成洋', ' 肇庆广宁', ' 软件学院', ' 音乐', null);
INSERT INTO `student` VALUES ('24', '1801130121', '吴有鹏', ' 惠州博罗', ' 软件学院', ' 看书', null);
INSERT INTO `student` VALUES ('25', '1801160122', '陈国葆', ' 梅州梅县', ' 软件学院', ' 读小说', null);
INSERT INTO `student` VALUES ('26', '1801030123', '赵雪妍', ' 汕尾海丰', ' 软件学院', ' 兵乓球', null);
INSERT INTO `student` VALUES ('27', '1801090124', '张雯嘉', ' 河源紫金', ' 软件学院', ' 足球，篮球，旅游，打游戏', null);
INSERT INTO `student` VALUES ('28', '1801100125', '岳晓震', ' 茂名电白', ' 软件学院', ' 跑步', null);
INSERT INTO `student` VALUES ('29', '1801110126', '李洋', ' 清远佛冈', ' 软件学院', ' 看电影', null);
INSERT INTO `student` VALUES ('30', '1801110127', '李京峰', ' 潮州潮安', ' 软件学院', ' 写小说，读书，看报纸', null);
INSERT INTO `student` VALUES ('31', '1801030128', '刘明', ' 茂名电白', ' 软件学院', ' 学习', null);
INSERT INTO `student` VALUES ('32', '1801050129', '陈耀', ' 广西桂林', ' 软件学院', ' 学习计算机技术', null);
INSERT INTO `student` VALUES ('33', '1801100130', '杨晓旭', ' 广西', ' 软件学院', ' 打篮球', null);
INSERT INTO `student` VALUES ('34', '1801060131', '张甜', ' 茂名电白', ' 软件学院', ' 音乐', null);
INSERT INTO `student` VALUES ('35', '1801070132', '王旭', '甘肃兰州', ' 软件学院', ' 看书', null);
INSERT INTO `student` VALUES ('36', '1801130133', '柴烨', ' 清远佛冈', ' 软件学院', ' 读小说', null);
INSERT INTO `student` VALUES ('37', '1801040134', '王飞', ' 清远佛冈', ' 软件学院', ' 兵乓球', null);
INSERT INTO `student` VALUES ('38', '1801140135', '赵子豪', ' 茂名电白', ' 软件学院', ' 足球，篮球，旅游，打游戏', null);
INSERT INTO `student` VALUES ('39', '1801110136', '张强', ' 河源紫金', ' 软件学院', ' 看电影', null);
INSERT INTO `student` VALUES ('40', '1801050137', '李洋', ' 茂名电白', ' 软件学院', ' 写小说，读书，看报纸', null);
INSERT INTO `student` VALUES ('41', '1801110138', '赵娜', ' 茂名电白', ' 软件学院', ' 学习', null);
INSERT INTO `student` VALUES ('42', '1801140139', '魏润英', ' 湛江遂溪', ' 软件学院', ' 看电影', null);
